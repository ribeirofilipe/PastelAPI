//== Class Definition
var Mail = function() {

    //== Public Functions
    return {
        // public functions
        init: function() {
            
        }
    };
}();

//== Class Initialization
jQuery(document).ready(function() {
    Mail.init();
});